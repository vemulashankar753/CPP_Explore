#include <iostream>

using namespace std;

class Vir{

  private:
   int a,b;

  public:

    Vir();
    Vir(int, int);
    int area();
};
