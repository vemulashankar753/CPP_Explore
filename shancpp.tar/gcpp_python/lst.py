#import list

lt1 = ["l1","l2","l3"]
print(lt1)
print("lenth is:%d", len(lt1))
lt1[1]= "l0"
lt1[4]= "l4"
print(lt1)
print(lt1.append["l5"])
print(lt1)
